import React, { createContext, useContext, useState } from 'react';
import { ProductType } from '../types/productTypes';
import { mockProducts } from '../data/mockProducts';

interface ProductContextType {
  products: ProductType[];
  featuredProducts: ProductType[];
  newArrivals: ProductType[];
  categories: string[];
  getProductById: (id: string) => ProductType | undefined;
  getSimilarProducts: (id: string, limit?: number) => ProductType[];
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};

export const ProductProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products] = useState<ProductType[]>(mockProducts);
  
  // Get featured products
  const featuredProducts = products
    .filter(product => product.isFeatured)
    .slice(0, 4);
  
  // Get new arrivals
  const newArrivals = products
    .filter(product => product.isNew)
    .slice(0, 4);
  
  // Get all unique categories
  const categories = Array.from(new Set(products.map(product => product.category)));
  
  // Get product by ID
  const getProductById = (id: string): ProductType | undefined => {
    return products.find(product => product.id === id);
  };
  
  // Get similar products
  const getSimilarProducts = (id: string, limit: number = 4): ProductType[] => {
    const currentProduct = getProductById(id);
    
    if (!currentProduct) return [];
    
    return products
      .filter(product => 
        product.id !== id && 
        product.category === currentProduct.category
      )
      .slice(0, limit);
  };
  
  return (
    <ProductContext.Provider 
      value={{ 
        products,
        featuredProducts,
        newArrivals,
        categories,
        getProductById,
        getSimilarProducts
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};