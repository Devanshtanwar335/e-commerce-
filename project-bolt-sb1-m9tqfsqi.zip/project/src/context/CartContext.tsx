import React, { createContext, useContext, useState, useEffect } from 'react';
import { ProductType, CartItemType, CartTotals } from '../types/productTypes';

interface CartContextType {
  cartItems: CartItemType[];
  addToCart: (product: CartItemType) => void;
  removeFromCart: (product: CartItemType) => void;
  updateQuantity: (product: CartItemType, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => CartTotals;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItemType[]>(() => {
    const savedItems = localStorage.getItem('cart');
    return savedItems ? JSON.parse(savedItems) : [];
  });
  
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cartItems));
  }, [cartItems]);
  
  const addToCart = (product: CartItemType) => {
    setCartItems(prevItems => {
      // Check if product is already in cart
      const existingItemIndex = prevItems.findIndex(item => {
        // Check if it's the same product with same options
        if (item.id !== product.id) return false;
        
        // If no options, just match by ID
        if (!item.selectedOptions && !product.selectedOptions) return true;
        
        // If one has options and the other doesn't, they're different
        if (!item.selectedOptions || !product.selectedOptions) return false;
        
        // Check if options match
        return (
          item.selectedOptions.size === product.selectedOptions.size &&
          item.selectedOptions.color === product.selectedOptions.color
        );
      });
      
      if (existingItemIndex !== -1) {
        // Product already in cart, update quantity
        const updatedItems = [...prevItems];
        updatedItems[existingItemIndex].quantity += product.quantity;
        return updatedItems;
      } else {
        // Add new product to cart
        return [...prevItems, { ...product }];
      }
    });
  };
  
  const removeFromCart = (product: CartItemType) => {
    setCartItems(prevItems => 
      prevItems.filter(item => {
        // If no options, just check ID
        if (!item.selectedOptions && !product.selectedOptions) {
          return item.id !== product.id;
        }
        
        // Check ID and options
        return !(
          item.id === product.id &&
          item.selectedOptions?.size === product.selectedOptions?.size &&
          item.selectedOptions?.color === product.selectedOptions?.color
        );
      })
    );
  };
  
  const updateQuantity = (product: CartItemType, quantity: number) => {
    setCartItems(prevItems => 
      prevItems.map(item => {
        // Check if this is the item to update
        const isMatch = item.id === product.id && 
          item.selectedOptions?.size === product.selectedOptions?.size &&
          item.selectedOptions?.color === product.selectedOptions?.color;
        
        if (isMatch) {
          return { ...item, quantity };
        }
        
        return item;
      })
    );
  };
  
  const clearCart = () => {
    setCartItems([]);
  };
  
  const getCartTotal = (): CartTotals => {
    const subtotal = cartItems.reduce((total, item) => {
      const price = item.discountPrice || item.price;
      return total + (price * item.quantity);
    }, 0);
    
    // Free shipping on orders over $75
    const shipping = subtotal > 75 ? 0 : 7.99;
    
    // Calculate tax (example: 8%)
    const tax = subtotal * 0.08;
    
    // Calculate discount (if any)
    const discount = cartItems.reduce((total, item) => {
      if (item.discountPrice) {
        return total + ((item.price - item.discountPrice) * item.quantity);
      }
      return total;
    }, 0);
    
    const total = subtotal + shipping + tax;
    
    return {
      subtotal,
      shipping,
      tax,
      discount,
      total
    };
  };
  
  return (
    <CartContext.Provider 
      value={{ 
        cartItems, 
        addToCart, 
        removeFromCart, 
        updateQuantity, 
        clearCart, 
        getCartTotal 
      }}
    >
      {children}
    </CartContext.Provider>
  );
};