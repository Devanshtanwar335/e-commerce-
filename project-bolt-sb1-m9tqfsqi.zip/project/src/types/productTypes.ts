export interface ProductType {
  id: string;
  name: string;
  description: string;
  fullDescription?: string;
  price: number;
  discountPrice?: number;
  category: string;
  images: string[];
  rating: number;
  reviewCount: number;
  isNew: boolean;
  isFeatured: boolean;
  variants?: {
    colors?: { name: string; value: string }[];
    sizes?: string[];
  };
  details?: string[];
  createdAt: string;
}

export interface CartItemType extends ProductType {
  quantity: number;
  selectedOptions?: {
    size?: string;
    color?: string;
  };
}

export interface CartTotals {
  subtotal: number;
  shipping: number;
  tax: number;
  discount: number;
  total: number;
}