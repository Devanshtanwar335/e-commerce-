import React, { useState } from 'react';
import { User, Package, Heart, CreditCard, Settings, LogOut } from 'lucide-react';

const AccountPage = () => {
  const [activeTab, setActiveTab] = useState('profile');
  
  // Mock user data
  const user = {
    name: 'Jessica Smith',
    email: 'jessica@example.com',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  };
  
  // Mock order data
  const orders = [
    {
      id: 'ORD-12345',
      date: '2023-05-15',
      status: 'Delivered',
      total: 128.5,
      items: 3
    },
    {
      id: 'ORD-12344',
      date: '2023-04-28',
      status: 'Processing',
      total: 78.99,
      items: 2
    },
    {
      id: 'ORD-12343',
      date: '2023-04-10',
      status: 'Delivered',
      total: 195.0,
      items: 1
    }
  ];
  
  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold text-slate-900 mb-8">My Account</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              {/* User Info */}
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center">
                  <img 
                    src={user.avatar} 
                    alt={user.name} 
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="ml-4">
                    <h3 className="text-base font-medium text-slate-900">{user.name}</h3>
                    <p className="text-sm text-gray-500">{user.email}</p>
                  </div>
                </div>
              </div>
              
              {/* Navigation */}
              <nav className="p-2">
                <button 
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center px-4 py-2 rounded-md text-left ${
                    activeTab === 'profile' 
                      ? 'bg-coral-50 text-coral-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <User size={18} className="mr-3" />
                  Profile
                </button>
                
                <button 
                  onClick={() => setActiveTab('orders')}
                  className={`w-full flex items-center px-4 py-2 rounded-md text-left ${
                    activeTab === 'orders' 
                      ? 'bg-coral-50 text-coral-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Package size={18} className="mr-3" />
                  Orders
                </button>
                
                <button 
                  onClick={() => setActiveTab('wishlist')}
                  className={`w-full flex items-center px-4 py-2 rounded-md text-left ${
                    activeTab === 'wishlist' 
                      ? 'bg-coral-50 text-coral-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Heart size={18} className="mr-3" />
                  Wishlist
                </button>
                
                <button 
                  onClick={() => setActiveTab('payment')}
                  className={`w-full flex items-center px-4 py-2 rounded-md text-left ${
                    activeTab === 'payment' 
                      ? 'bg-coral-50 text-coral-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <CreditCard size={18} className="mr-3" />
                  Payment Methods
                </button>
                
                <button 
                  onClick={() => setActiveTab('settings')}
                  className={`w-full flex items-center px-4 py-2 rounded-md text-left ${
                    activeTab === 'settings' 
                      ? 'bg-coral-50 text-coral-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Settings size={18} className="mr-3" />
                  Settings
                </button>
                
                <button className="w-full flex items-center px-4 py-2 rounded-md text-left text-gray-700 hover:bg-gray-50">
                  <LogOut size={18} className="mr-3" />
                  Log Out
                </button>
              </nav>
            </div>
          </div>
          
          {/* Main Content */}
          <div className="md:col-span-3">
            {activeTab === 'profile' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold text-slate-900 mb-6">Profile Information</h2>
                
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                        First Name
                      </label>
                      <input 
                        type="text" 
                        id="firstName" 
                        defaultValue="Jessica" 
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-coral-600"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name
                      </label>
                      <input 
                        type="text" 
                        id="lastName" 
                        defaultValue="Smith" 
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-coral-600"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input 
                      type="email" 
                      id="email" 
                      defaultValue={user.email} 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-coral-600"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input 
                      type="tel" 
                      id="phone" 
                      defaultValue="(555) 123-4567" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-coral-600"
                    />
                  </div>
                  
                  <div>
                    <h3 className="text-md font-medium text-gray-900 mb-3">Change Password</h3>
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="currentPassword" className="block text-sm font-medium text-gray-700 mb-1">
                          Current Password
                        </label>
                        <input 
                          type="password" 
                          id="currentPassword" 
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-coral-600"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 mb-1">
                          New Password
                        </label>
                        <input 
                          type="password" 
                          id="newPassword" 
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-coral-600"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                          Confirm New Password
                        </label>
                        <input 
                          type="password" 
                          id="confirmPassword" 
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-coral-600"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <button 
                      type="submit" 
                      className="bg-coral-600 hover:bg-coral-700 text-white font-medium px-6 py-3 rounded-md transition-colors"
                    >
                      Save Changes
                    </button>
                  </div>
                </form>
              </div>
            )}
            
            {activeTab === 'orders' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold text-slate-900 mb-6">Order History</h2>
                
                {orders.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Items</th>
                          <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {orders.map(order => (
                          <tr key={order.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-coral-600">{order.id}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.date}</td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                order.status === 'Delivered' 
                                  ? 'bg-green-100 text-green-700' 
                                  : 'bg-blue-100 text-blue-700'
                              }`}>
                                {order.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${order.total.toFixed(2)}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.items}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                              <button className="text-coral-600 hover:text-coral-700 font-medium">View Details</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-10">
                    <Package size={48} className="mx-auto text-gray-300" />
                    <h3 className="mt-2 text-sm font-semibold text-gray-900">No orders yet</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      When you place orders, they will appear here.
                    </p>
                  </div>
                )}
              </div>
            )}
            
            {activeTab === 'wishlist' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold text-slate-900 mb-6">My Wishlist</h2>
                
                <div className="text-center py-10">
                  <Heart size={48} className="mx-auto text-gray-300" />
                  <h3 className="mt-2 text-sm font-semibold text-gray-900">Your wishlist is empty</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Save your favorite items to your wishlist for easy access later.
                  </p>
                  <button className="mt-4 bg-coral-600 hover:bg-coral-700 text-white font-medium px-4 py-2 rounded-md transition-colors">
                    Explore Products
                  </button>
                </div>
              </div>
            )}
            
            {activeTab === 'payment' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold text-slate-900 mb-6">Payment Methods</h2>
                
                <div className="mb-6">
                  <button className="bg-slate-800 hover:bg-slate-900 text-white font-medium px-4 py-2 rounded-md transition-colors flex items-center">
                    <CreditCard size={18} className="mr-2" />
                    Add Payment Method
                  </button>
                </div>
                
                <div className="text-center py-10">
                  <CreditCard size={48} className="mx-auto text-gray-300" />
                  <h3 className="mt-2 text-sm font-semibold text-gray-900">No payment methods added</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Add a payment method to make checkout faster.
                  </p>
                </div>
              </div>
            )}
            
            {activeTab === 'settings' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold text-slate-900 mb-6">Account Settings</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-md font-medium text-gray-900 mb-3">Email Notifications</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input 
                          id="orderUpdates" 
                          type="checkbox" 
                          defaultChecked 
                          className="h-4 w-4 rounded border-gray-300 text-coral-600 focus:ring-coral-500"
                        />
                        <label htmlFor="orderUpdates" className="ml-2 text-sm text-gray-700">
                          Order updates and shipping notifications
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input 
                          id="promotions" 
                          type="checkbox" 
                          defaultChecked 
                          className="h-4 w-4 rounded border-gray-300 text-coral-600 focus:ring-coral-500"
                        />
                        <label htmlFor="promotions" className="ml-2 text-sm text-gray-700">
                          Promotions and new product announcements
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input 
                          id="newsletter" 
                          type="checkbox" 
                          defaultChecked 
                          className="h-4 w-4 rounded border-gray-300 text-coral-600 focus:ring-coral-500"
                        />
                        <label htmlFor="newsletter" className="ml-2 text-sm text-gray-700">
                          Weekly newsletter with fashion trends
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-6">
                    <h3 className="text-md font-medium text-gray-900 mb-3">Privacy Settings</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input 
                          id="browsing" 
                          type="checkbox" 
                          defaultChecked 
                          className="h-4 w-4 rounded border-gray-300 text-coral-600 focus:ring-coral-500"
                        />
                        <label htmlFor="browsing" className="ml-2 text-sm text-gray-700">
                          Store browsing history for personalized recommendations
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input 
                          id="thirdParty" 
                          type="checkbox" 
                          className="h-4 w-4 rounded border-gray-300 text-coral-600 focus:ring-coral-500"
                        />
                        <label htmlFor="thirdParty" className="ml-2 text-sm text-gray-700">
                          Allow sharing information with trusted third parties
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-6">
                    <h3 className="text-md font-medium text-red-600 mb-3">Danger Zone</h3>
                    <button className="text-red-600 hover:text-red-700 font-medium text-sm">
                      Delete Account
                    </button>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-6">
                    <button 
                      type="submit" 
                      className="bg-coral-600 hover:bg-coral-700 text-white font-medium px-6 py-3 rounded-md transition-colors"
                    >
                      Save Settings
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountPage;