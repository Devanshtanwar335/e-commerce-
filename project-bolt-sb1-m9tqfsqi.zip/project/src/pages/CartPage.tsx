import React from 'react';
import { Link } from 'react-router-dom';
import { Trash2, ShoppingBag, ChevronRight } from 'lucide-react';
import { useCart } from '../context/CartContext';

const CartPage = () => {
  const { cartItems, removeFromCart, updateQuantity, getCartTotal } = useCart();
  
  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <ShoppingBag size={64} className="mx-auto text-gray-300" />
          <h1 className="mt-4 text-2xl font-bold text-slate-900">Your cart is empty</h1>
          <p className="mt-2 text-gray-600">Looks like you haven't added any products to your cart yet.</p>
          <Link 
            to="/products" 
            className="mt-8 inline-block bg-coral-600 hover:bg-coral-700 text-white font-medium px-6 py-3 rounded-md transition-colors"
          >
            Continue Shopping
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-slate-900 mb-8">Your Cart</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow-sm">
            <div className="p-6">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">
                Cart Items ({cartItems.length})
              </h2>
              
              {/* Items List */}
              <div className="divide-y divide-gray-200">
                {cartItems.map(item => (
                  <div key={`${item.id}-${item.selectedOptions?.size}-${item.selectedOptions?.color}`} className="py-6 flex flex-col sm:flex-row">
                    {/* Product Image */}
                    <div className="flex-shrink-0 w-full sm:w-24 h-24 bg-gray-100 rounded-md overflow-hidden mb-4 sm:mb-0">
                      <img 
                        src={item.images[0]} 
                        alt={item.name} 
                        className="w-full h-full object-cover object-center"
                      />
                    </div>
                    
                    {/* Product Details */}
                    <div className="flex-1 sm:ml-6">
                      <div className="flex justify-between">
                        <div>
                          <h3 className="text-base font-medium text-slate-900">
                            <Link to={`/products/${item.id}`} className="hover:text-coral-600">
                              {item.name}
                            </Link>
                          </h3>
                          {item.selectedOptions && (
                            <div className="mt-1 text-sm text-gray-500">
                              {item.selectedOptions.color && (
                                <span className="mr-4">Color: {item.selectedOptions.color}</span>
                              )}
                              {item.selectedOptions.size && (
                                <span>Size: {item.selectedOptions.size}</span>
                              )}
                            </div>
                          )}
                          <div className="mt-2">
                            <span className="text-sm font-medium text-slate-900">
                              ${(item.discountPrice || item.price).toFixed(2)}
                            </span>
                            {item.discountPrice && (
                              <span className="ml-2 text-sm text-gray-500 line-through">
                                ${item.price.toFixed(2)}
                              </span>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex flex-col justify-between items-end">
                          {/* Quantity */}
                          <div className="flex border border-gray-300 rounded-md">
                            <button 
                              onClick={() => updateQuantity(item, Math.max(1, item.quantity - 1))}
                              className="px-2 py-1 border-r border-gray-300"
                            >
                              -
                            </button>
                            <input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => updateQuantity(item, Math.max(1, parseInt(e.target.value) || 1))}
                              className="w-12 text-center focus:outline-none"
                            />
                            <button 
                              onClick={() => updateQuantity(item, item.quantity + 1)}
                              className="px-2 py-1 border-l border-gray-300"
                            >
                              +
                            </button>
                          </div>
                          
                          {/* Remove Button */}
                          <button 
                            onClick={() => removeFromCart(item)}
                            className="mt-4 text-sm text-gray-500 hover:text-red-600 flex items-center"
                          >
                            <Trash2 size={16} className="mr-1" />
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Continue Shopping */}
              <div className="mt-6">
                <Link 
                  to="/products" 
                  className="text-coral-600 hover:text-coral-700 font-medium flex items-center"
                >
                  <ChevronRight size={16} className="transform rotate-180 mr-1" />
                  Continue Shopping
                </Link>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="bg-white rounded-lg shadow-sm p-6 h-fit">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">Order Summary</h2>
            
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span className="font-medium">${getCartTotal().subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Shipping</span>
                <span className="font-medium">${getCartTotal().shipping.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tax</span>
                <span className="font-medium">${getCartTotal().tax.toFixed(2)}</span>
              </div>
              
              {getCartTotal().discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount</span>
                  <span className="font-medium">-${getCartTotal().discount.toFixed(2)}</span>
                </div>
              )}
              
              <div className="border-t border-gray-200 pt-4 flex justify-between">
                <span className="font-medium text-slate-900">Total</span>
                <span className="font-bold text-lg">${getCartTotal().total.toFixed(2)}</span>
              </div>
            </div>
            
            {/* Promo Code */}
            <div className="mt-6">
              <label htmlFor="promo" className="block text-sm font-medium text-gray-700 mb-2">
                Promo Code
              </label>
              <div className="flex">
                <input
                  type="text"
                  id="promo"
                  placeholder="Enter code"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-coral-600"
                />
                <button className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2 rounded-r-md transition-colors">
                  Apply
                </button>
              </div>
            </div>
            
            {/* Checkout Button */}
            <button className="mt-6 w-full bg-coral-600 hover:bg-coral-700 text-white font-medium py-3 rounded-md transition-colors">
              Proceed to Checkout
            </button>
            
            {/* Payment Methods */}
            <div className="mt-6 text-center">
              <p className="text-xs text-gray-500 mb-2">We accept the following payment methods</p>
              <div className="flex justify-center space-x-2">
                <div className="w-10 h-6 bg-gray-200 rounded"></div>
                <div className="w-10 h-6 bg-gray-200 rounded"></div>
                <div className="w-10 h-6 bg-gray-200 rounded"></div>
                <div className="w-10 h-6 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;