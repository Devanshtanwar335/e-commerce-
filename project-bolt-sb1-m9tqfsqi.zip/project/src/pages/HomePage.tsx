import React from 'react';
import { ArrowRight, TrendingUp, Package, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/products/ProductCard';
import { useProducts } from '../context/ProductContext';

const HomePage = () => {
  const { featuredProducts, newArrivals } = useProducts();

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[80vh] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 to-slate-900/20">
          <img 
            src="https://images.pexels.com/photos/5868722/pexels-photo-5868722.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
            alt="Fashion model showcase" 
            className="absolute inset-0 w-full h-full object-cover object-center"
          />
        </div>
        <div className="relative container mx-auto px-4 h-full flex flex-col justify-center">
          <div className="max-w-xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight animate-fadeInUp">
              Discover Your Signature Style
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mt-4 animate-fadeInUp animation-delay-100">
              Explore our latest collection inspired by modern minimalism and timeless elegance.
            </p>
            <div className="mt-8 flex space-x-4 animate-fadeInUp animation-delay-200">
              <Link 
                to="/products" 
                className="bg-coral-600 hover:bg-coral-700 text-white px-6 py-3 rounded-md font-medium transition-colors flex items-center"
              >
                Shop Now <ArrowRight size={18} className="ml-2" />
              </Link>
              <Link 
                to="/products/new" 
                className="bg-transparent border border-white text-white hover:bg-white/10 px-6 py-3 rounded-md font-medium transition-colors"
              >
                New Arrivals
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Shop by Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Link 
              to="/products/men"
              className="group relative h-80 overflow-hidden rounded-lg shadow-lg transition-transform hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="absolute inset-0 bg-slate-900/30 group-hover:bg-slate-900/20 transition-colors z-10"></div>
              <img 
                src="https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Men's Collection" 
                className="h-full w-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="text-white text-2xl font-bold z-20 bg-slate-900/40 px-6 py-2 rounded-md">Men's Collection</h3>
              </div>
            </Link>

            <Link 
              to="/products/women"
              className="group relative h-80 overflow-hidden rounded-lg shadow-lg transition-transform hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="absolute inset-0 bg-slate-900/30 group-hover:bg-slate-900/20 transition-colors z-10"></div>
              <img 
                src="https://images.pexels.com/photos/949670/pexels-photo-949670.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Women's Collection" 
                className="h-full w-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="text-white text-2xl font-bold z-20 bg-slate-900/40 px-6 py-2 rounded-md">Women's Collection</h3>
              </div>
            </Link>

            <Link 
              to="/products/accessories"
              className="group relative h-80 overflow-hidden rounded-lg shadow-lg transition-transform hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="absolute inset-0 bg-slate-900/30 group-hover:bg-slate-900/20 transition-colors z-10"></div>
              <img 
                src="https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Accessories" 
                className="h-full w-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="text-white text-2xl font-bold z-20 bg-slate-900/40 px-6 py-2 rounded-md">Accessories</h3>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Featured Products</h2>
            <Link to="/products" className="mt-4 md:mt-0 text-coral-600 hover:text-coral-700 font-medium flex items-center group">
              View All Products 
              <ArrowRight size={18} className="ml-2 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="p-6 rounded-lg">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-coral-100 text-coral-600 rounded-full mb-4">
                <TrendingUp size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-slate-900">Latest Trends</h3>
              <p className="text-gray-600">
                Stay ahead with our curated collection of the latest fashion trends and styles
              </p>
            </div>

            <div className="p-6 rounded-lg">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-coral-100 text-coral-600 rounded-full mb-4">
                <Package size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-slate-900">Free Shipping</h3>
              <p className="text-gray-600">
                Enjoy free shipping on all orders over $50 within the continental US
              </p>
            </div>

            <div className="p-6 rounded-lg">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-coral-100 text-coral-600 rounded-full mb-4">
                <ShieldCheck size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-slate-900">Quality Guaranteed</h3>
              <p className="text-gray-600">
                We stand behind the quality of our products with a 30-day satisfaction guarantee
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12">
            <h2 className="text-3xl font-bold text-slate-900">New Arrivals</h2>
            <Link to="/products/new" className="mt-4 md:mt-0 text-coral-600 hover:text-coral-700 font-medium flex items-center group">
              View All New Arrivals 
              <ArrowRight size={18} className="ml-2 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {newArrivals.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Newsletter */}
      <section className="py-20 bg-slate-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Get 10% Off Your First Order</h2>
            <p className="text-gray-300 mb-8">
              Subscribe to our newsletter for updates on new products, special offers, and exclusive content.
            </p>
            <div className="flex flex-col sm:flex-row mx-auto max-w-lg">
              <input
                type="email"
                placeholder="Your email address"
                className="px-4 py-3 rounded-l-md flex-grow text-slate-900 focus:outline-none"
              />
              <button className="bg-coral-600 hover:bg-coral-700 px-6 py-3 rounded-md sm:rounded-l-none font-medium transition-colors mt-2 sm:mt-0">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;