import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, Heart, Share2, Star, Truck, RotateCw, Shield } from 'lucide-react';
import { useProducts } from '../context/ProductContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import ProductCard from '../components/products/ProductCard';

const ProductDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const { getProductById, getSimilarProducts } = useProducts();
  const { addToCart } = useCart();
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist();
  
  const product = getProductById(id || '');
  const similarProducts = getSimilarProducts(id || '');
  
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-semibold mb-4">Product Not Found</h1>
        <p className="mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Link 
          to="/products" 
          className="bg-coral-600 hover:bg-coral-700 text-white px-6 py-3 rounded-md font-medium transition-colors"
        >
          Back to Products
        </Link>
      </div>
    );
  }
  
  const handleAddToCart = () => {
    if (product.variants && (!selectedSize || !selectedColor)) {
      // Show validation error
      return;
    }
    
    addToCart({
      ...product,
      quantity,
      selectedOptions: {
        size: selectedSize,
        color: selectedColor
      }
    });
  };
  
  const handleWishlist = () => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  return (
    <div className="bg-white">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumbs */}
        <nav className="flex text-sm text-gray-500 mb-8">
          <Link to="/" className="hover:text-coral-600">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/products" className="hover:text-coral-600">Products</Link>
          <span className="mx-2">/</span>
          <Link to={`/products?category=${product.category}`} className="hover:text-coral-600 capitalize">
            {product.category}
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-700">{product.name}</span>
        </nav>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg overflow-hidden">
              <img 
                src={product.images[selectedImage]} 
                alt={product.name} 
                className="w-full h-[500px] object-cover object-center"
              />
            </div>
            
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {product.images.map((image, index) => (
                  <button 
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-md overflow-hidden flex-shrink-0 border-2 ${
                      selectedImage === index ? 'border-coral-600' : 'border-transparent'
                    }`}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} view ${index + 1}`} 
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {/* Product Info */}
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{product.name}</h1>
            
            {/* Ratings */}
            <div className="flex items-center mt-2 mb-4">
              <div className="flex">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star 
                    key={star}
                    size={18}
                    className={star <= product.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}
                  />
                ))}
              </div>
              <span className="ml-2 text-sm text-gray-600">
                {product.reviewCount} reviews
              </span>
            </div>
            
            {/* Price */}
            <div className="mb-6">
              {product.discountPrice ? (
                <div className="flex items-center">
                  <span className="text-2xl font-bold text-slate-900">${product.discountPrice}</span>
                  <span className="ml-3 text-lg text-gray-500 line-through">${product.price}</span>
                  <span className="ml-3 bg-coral-100 text-coral-600 px-2 py-1 rounded text-sm font-semibold">
                    {Math.round((1 - product.discountPrice / product.price) * 100)}% OFF
                  </span>
                </div>
              ) : (
                <span className="text-2xl font-bold text-slate-900">${product.price}</span>
              )}
            </div>
            
            {/* Description */}
            <p className="text-gray-600 mb-6">{product.description}</p>
            
            {/* Color Selection */}
            {product.variants?.colors && (
              <div className="mb-6">
                <h3 className="text-sm font-medium mb-2">Color: {selectedColor || 'Select a color'}</h3>
                <div className="flex space-x-2">
                  {product.variants.colors.map(color => (
                    <button
                      key={color.name}
                      onClick={() => setSelectedColor(color.name)}
                      className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${
                        selectedColor === color.name ? 'border-slate-900' : 'border-gray-300'
                      }`}
                      style={{ backgroundColor: color.value }}
                      aria-label={color.name}
                    >
                      {selectedColor === color.name && <div className="w-2 h-2 rounded-full bg-white" />}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Size Selection */}
            {product.variants?.sizes && (
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-medium">Size: {selectedSize || 'Select a size'}</h3>
                  <button className="text-sm text-coral-600 hover:text-coral-700">Size Guide</button>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {product.variants.sizes.map(size => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`py-2 border rounded-md ${
                        selectedSize === size 
                          ? 'border-slate-900 bg-slate-900 text-white' 
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Quantity */}
            <div className="mb-6">
              <h3 className="text-sm font-medium mb-2">Quantity</h3>
              <div className="flex border border-gray-300 rounded-md w-32">
                <button 
                  onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                  className="px-3 py-2 border-r border-gray-300"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full text-center focus:outline-none"
                />
                <button 
                  onClick={() => setQuantity(prev => prev + 1)}
                  className="px-3 py-2 border-l border-gray-300"
                >
                  +
                </button>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button
                onClick={handleAddToCart}
                className="flex-1 bg-coral-600 hover:bg-coral-700 text-white font-medium px-6 py-3 rounded-md transition-colors flex items-center justify-center"
              >
                <ShoppingCart size={18} className="mr-2" />
                Add to Cart
              </button>
              <button
                onClick={handleWishlist}
                className={`
                  px-4 py-3 rounded-md border transition-colors
                  ${isInWishlist(product.id) 
                    ? 'bg-pink-50 border-pink-200 text-pink-500' 
                    : 'border-gray-300 hover:border-gray-400'}
                `}
              >
                <Heart 
                  size={18} 
                  className={isInWishlist(product.id) ? 'fill-pink-500' : ''} 
                />
              </button>
              <button
                className="px-4 py-3 rounded-md border border-gray-300 hover:border-gray-400 transition-colors"
              >
                <Share2 size={18} />
              </button>
            </div>
            
            {/* Shipping & Returns */}
            <div className="border-t border-gray-200 pt-6 space-y-4">
              <div className="flex">
                <Truck size={20} className="text-gray-500 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-sm">Free Shipping & Returns</h4>
                  <p className="text-sm text-gray-500">Free standard shipping on orders over $50</p>
                </div>
              </div>
              <div className="flex">
                <RotateCw size={20} className="text-gray-500 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-sm">30-Day Returns</h4>
                  <p className="text-sm text-gray-500">Return or exchange within 30 days</p>
                </div>
              </div>
              <div className="flex">
                <Shield size={20} className="text-gray-500 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-sm">Secure Payments</h4>
                  <p className="text-sm text-gray-500">Your payment information is processed securely</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Product Details Tabs */}
        <div className="mt-16 border-t border-gray-200 pt-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8">
              <button className="border-b-2 border-coral-600 py-4 px-1 text-sm font-medium text-coral-600">
                Description
              </button>
              <button className="border-b-2 border-transparent py-4 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300">
                Additional Information
              </button>
              <button className="border-b-2 border-transparent py-4 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300">
                Reviews ({product.reviewCount})
              </button>
            </nav>
          </div>
          <div className="py-8 prose max-w-none">
            <p>{product.fullDescription || product.description}</p>
            <ul className="mt-4">
              {product.details?.map((detail, index) => (
                <li key={index}>{detail}</li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Similar Products */}
        {similarProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-slate-900 mb-8">You might also like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {similarProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetailPage;