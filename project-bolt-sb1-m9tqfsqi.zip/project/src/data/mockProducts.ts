import { ProductType } from '../types/productTypes';

export const mockProducts: ProductType[] = [
  {
    id: "p1",
    name: "Classic Cotton T-Shirt",
    description: "Soft, breathable cotton T-shirt with a comfortable fit and classic style.",
    fullDescription: "This essential t-shirt is crafted from premium cotton for breathability and comfort. The classic fit makes it perfect for everyday wear, and the durable construction ensures it maintains its shape wash after wash.",
    price: 29.99,
    category: "men",
    images: [
      "https://images.pexels.com/photos/1656684/pexels-photo-1656684.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/1484807/pexels-photo-1484807.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4,
    reviewCount: 128,
    isNew: false,
    isFeatured: true,
    variants: {
      colors: [
        { name: "White", value: "#ffffff" },
        { name: "Black", value: "#000000" },
        { name: "Navy", value: "#0a192f" }
      ],
      sizes: ["S", "M", "L", "XL"]
    },
    details: [
      "100% premium cotton",
      "Regular fit",
      "Crewneck",
      "Machine washable",
      "Imported"
    ],
    createdAt: "2023-01-15"
  },
  {
    id: "p2",
    name: "Slim Fit Jeans",
    description: "Modern slim fit jeans with stretch for comfort and mobility.",
    price: 59.99,
    category: "men",
    images: [
      "https://images.pexels.com/photos/1346187/pexels-photo-1346187.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/52518/jeans-pants-blue-shop-52518.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4.5,
    reviewCount: 95,
    isNew: false,
    isFeatured: true,
    variants: {
      colors: [
        { name: "Light Blue", value: "#a0c8e2" },
        { name: "Dark Blue", value: "#0d47a1" },
        { name: "Black", value: "#000000" }
      ],
      sizes: ["30x30", "32x30", "32x32", "34x32", "36x32"]
    },
    createdAt: "2023-02-10"
  },
  {
    id: "p3",
    name: "Floral Summer Dress",
    description: "Light, flowy summer dress with a gorgeous floral pattern.",
    price: 79.99,
    discountPrice: 59.99,
    category: "women",
    images: [
      "https://images.pexels.com/photos/972995/pexels-photo-972995.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/914668/pexels-photo-914668.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 5,
    reviewCount: 42,
    isNew: false,
    isFeatured: true,
    variants: {
      colors: [
        { name: "Blue Floral", value: "#4c72b0" },
        { name: "Red Floral", value: "#c92a2a" }
      ],
      sizes: ["XS", "S", "M", "L"]
    },
    createdAt: "2023-03-05"
  },
  {
    id: "p4",
    name: "Leather Crossbody Bag",
    description: "Stylish genuine leather crossbody bag with multiple compartments.",
    price: 99.99,
    category: "accessories",
    images: [
      "https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/934673/pexels-photo-934673.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4.5,
    reviewCount: 67,
    isNew: true,
    isFeatured: true,
    variants: {
      colors: [
        { name: "Tan", value: "#D2B48C" },
        { name: "Black", value: "#000000" },
        { name: "Brown", value: "#5D4037" }
      ]
    },
    createdAt: "2023-05-15"
  },
  {
    id: "p5",
    name: "Running Sneakers",
    description: "Lightweight, responsive running shoes with breathable mesh upper.",
    price: 129.99,
    discountPrice: 99.99,
    category: "men",
    images: [
      "https://images.pexels.com/photos/1456706/pexels-photo-1456706.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4,
    reviewCount: 88,
    isNew: true,
    isFeatured: false,
    variants: {
      colors: [
        { name: "Black/White", value: "#000000" },
        { name: "Blue/Orange", value: "#0d47a1" },
        { name: "Grey/Red", value: "#9e9e9e" }
      ],
      sizes: ["8", "9", "10", "11", "12"]
    },
    createdAt: "2023-06-02"
  },
  {
    id: "p6",
    name: "Designer Sunglasses",
    description: "UV protective designer sunglasses with polarized lenses.",
    price: 159.99,
    category: "accessories",
    images: [
      "https://images.pexels.com/photos/46710/pexels-photo-46710.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/701877/pexels-photo-701877.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4.5,
    reviewCount: 36,
    isNew: false,
    isFeatured: false,
    variants: {
      colors: [
        { name: "Black", value: "#000000" },
        { name: "Tortoise", value: "#8B4513" }
      ]
    },
    createdAt: "2023-02-28"
  },
  {
    id: "p7",
    name: "Cashmere Sweater",
    description: "Luxuriously soft cashmere sweater, perfect for cooler weather.",
    price: 199.99,
    discountPrice: 149.99,
    category: "women",
    images: [
      "https://images.pexels.com/photos/45982/pexels-photo-45982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/6311392/pexels-photo-6311392.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 5,
    reviewCount: 24,
    isNew: false,
    isFeatured: false,
    variants: {
      colors: [
        { name: "Cream", value: "#FFF8DC" },
        { name: "Grey", value: "#9e9e9e" },
        { name: "Black", value: "#000000" }
      ],
      sizes: ["XS", "S", "M", "L", "XL"]
    },
    createdAt: "2023-01-05"
  },
  {
    id: "p8",
    name: "Smart Watch",
    description: "Feature-packed smartwatch with fitness tracking and notifications.",
    price: 249.99,
    category: "accessories",
    images: [
      "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/393047/pexels-photo-393047.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4,
    reviewCount: 55,
    isNew: true,
    isFeatured: false,
    variants: {
      colors: [
        { name: "Black", value: "#000000" },
        { name: "Silver", value: "#C0C0C0" }
      ]
    },
    createdAt: "2023-06-10"
  },
  {
    id: "p9",
    name: "Linen Blazer",
    description: "Lightweight linen blazer, perfect for summer occasions.",
    price: 169.99,
    category: "men",
    images: [
      "https://images.pexels.com/photos/2905824/pexels-photo-2905824.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/2697391/pexels-photo-2697391.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4,
    reviewCount: 41,
    isNew: true,
    isFeatured: false,
    variants: {
      colors: [
        { name: "Beige", value: "#F5F5DC" },
        { name: "Navy", value: "#0a192f" },
        { name: "Light Grey", value: "#D3D3D3" }
      ],
      sizes: ["S", "M", "L", "XL", "XXL"]
    },
    createdAt: "2023-05-28"
  },
  {
    id: "p10",
    name: "Pleated Midi Skirt",
    description: "Elegant pleated midi skirt with a flattering silhouette.",
    price: 89.99,
    category: "women",
    images: [
      "https://images.pexels.com/photos/6764032/pexels-photo-6764032.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/7691066/pexels-photo-7691066.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4.5,
    reviewCount: 29,
    isNew: true,
    isFeatured: false,
    variants: {
      colors: [
        { name: "Black", value: "#000000" },
        { name: "Beige", value: "#F5F5DC" },
        { name: "Emerald", value: "#046307" }
      ],
      sizes: ["XS", "S", "M", "L"]
    },
    createdAt: "2023-05-30"
  },
  {
    id: "p11",
    name: "Leather Wallet",
    description: "Genuine leather wallet with RFID protection and multiple card slots.",
    price: 49.99,
    category: "accessories",
    images: [
      "https://images.pexels.com/photos/2079438/pexels-photo-2079438.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/4452526/pexels-photo-4452526.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4,
    reviewCount: 75,
    isNew: false,
    isFeatured: false,
    variants: {
      colors: [
        { name: "Brown", value: "#5D4037" },
        { name: "Black", value: "#000000" }
      ]
    },
    createdAt: "2023-03-12"
  },
  {
    id: "p12",
    name: "Silk Blouse",
    description: "Luxurious silk blouse with an elegant drape and timeless style.",
    price: 119.99,
    category: "women",
    images: [
      "https://images.pexels.com/photos/5693889/pexels-photo-5693889.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      "https://images.pexels.com/photos/7691121/pexels-photo-7691121.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    ],
    rating: 4.5,
    reviewCount: 33,
    isNew: false,
    isFeatured: false,
    variants: {
      colors: [
        { name: "White", value: "#ffffff" },
        { name: "Black", value: "#000000" },
        { name: "Navy", value: "#0a192f" }
      ],
      sizes: ["XS", "S", "M", "L", "XL"]
    },
    createdAt: "2023-02-25"
  }
];