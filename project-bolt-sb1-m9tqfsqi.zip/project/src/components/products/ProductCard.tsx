import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Heart, Eye } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { ProductType } from '../../types/productTypes';

interface ProductCardProps {
  product: ProductType;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [isHovered, setIsHovered] = useState(false);
  const { addToCart } = useCart();
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist();
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart({ ...product, quantity: 1 });
  };
  
  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  return (
    <div 
      className="group relative bg-white rounded-lg shadow-sm overflow-hidden transition-transform hover:-translate-y-1 hover:shadow-md"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Product Image */}
      <Link to={`/products/${product.id}`} className="block aspect-square overflow-hidden">
        <img 
          src={isHovered && product.images.length > 1 ? product.images[1] : product.images[0]} 
          alt={product.name} 
          className="w-full h-full object-cover object-center transition-transform group-hover:scale-105"
        />
      </Link>
      
      {/* Quick Actions */}
      <div className="absolute top-0 right-0 p-2 z-10">
        <button 
          onClick={handleWishlist}
          className={`
            flex items-center justify-center w-8 h-8 rounded-full shadow-md transition-colors
            ${isInWishlist(product.id) 
              ? 'bg-pink-100 text-pink-500' 
              : 'bg-white text-gray-600 hover:text-coral-600'}
          `}
        >
          <Heart size={16} className={isInWishlist(product.id) ? 'fill-pink-500' : ''} />
        </button>
      </div>
      
      {/* Action Buttons */}
      <div className={`
        absolute bottom-0 left-0 right-0 bg-white bg-opacity-95 p-3 flex items-center space-x-2
        transition-all duration-300 transform ${isHovered ? 'translate-y-0' : 'translate-y-full'}
      `}>
        <button 
          onClick={handleAddToCart}
          className="flex-1 bg-coral-600 hover:bg-coral-700 text-white text-sm font-medium py-2 rounded-md transition-colors flex items-center justify-center"
        >
          <ShoppingCart size={14} className="mr-1" />
          Add to Cart
        </button>
        <Link 
          to={`/products/${product.id}`}
          className="flex items-center justify-center w-9 h-9 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
        >
          <Eye size={16} />
        </Link>
      </div>
      
      {/* Sale or New Tag */}
      {product.isNew && (
        <div className="absolute top-2 left-2 bg-slate-900 text-white text-xs font-bold px-2 py-1 rounded">
          NEW
        </div>
      )}
      {product.discountPrice && (
        <div className="absolute top-2 left-2 bg-coral-600 text-white text-xs font-bold px-2 py-1 rounded">
          SALE
        </div>
      )}
      
      {/* Product Info */}
      <div className="p-4">
        <h3 className="text-sm font-medium text-slate-900 mb-1 line-clamp-1">
          <Link to={`/products/${product.id}`} className="hover:text-coral-600">
            {product.name}
          </Link>
        </h3>
        <p className="text-xs text-gray-500 mb-2 capitalize">{product.category}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {product.discountPrice ? (
              <>
                <span className="text-sm font-semibold text-slate-900">${product.discountPrice.toFixed(2)}</span>
                <span className="ml-2 text-xs text-gray-500 line-through">${product.price.toFixed(2)}</span>
              </>
            ) : (
              <span className="text-sm font-semibold text-slate-900">${product.price.toFixed(2)}</span>
            )}
          </div>
          
          {/* Rating */}
          <div className="flex items-center">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <svg 
                  key={i} 
                  className={`w-3 h-3 ${i < product.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <span className="ml-1 text-xs text-gray-500">({product.reviewCount})</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;