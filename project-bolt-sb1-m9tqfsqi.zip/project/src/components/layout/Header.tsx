import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Heart, User, Search, Menu, X } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { cartItems } = useCart();
  const { wishlistItems } = useWishlist();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <header 
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        isScrolled 
          ? 'bg-white shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="text-2xl font-bold text-slate-900">
            Lumin<span className="text-coral-600">ance</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link to="/" className="text-slate-800 hover:text-coral-600 transition-colors">
              Home
            </Link>
            <Link to="/products" className="text-slate-800 hover:text-coral-600 transition-colors">
              Shop
            </Link>
            <Link to="/about" className="text-slate-800 hover:text-coral-600 transition-colors">
              About
            </Link>
            <Link to="/contact" className="text-slate-800 hover:text-coral-600 transition-colors">
              Contact
            </Link>
          </nav>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 text-slate-800 hover:text-coral-600 transition-colors"
            >
              <Search size={20} />
            </button>
            <Link to="/account" className="p-2 text-slate-800 hover:text-coral-600 transition-colors">
              <User size={20} />
            </Link>
            <Link to="/wishlist" className="p-2 text-slate-800 hover:text-coral-600 transition-colors relative">
              <Heart size={20} />
              {wishlistItems.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-coral-600 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {wishlistItems.length}
                </span>
              )}
            </Link>
            <Link to="/cart" className="p-2 text-slate-800 hover:text-coral-600 transition-colors relative">
              <ShoppingCart size={20} />
              {cartItems.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-coral-600 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {cartItems.length}
                </span>
              )}
            </Link>
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 ml-2 text-slate-800 md:hidden"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="mt-4 px-4 relative animate-fadeDown">
            <input
              type="text"
              placeholder="Search for products..."
              className="w-full p-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-coral-600"
            />
            <Search size={18} className="absolute left-8 top-3 text-gray-400" />
          </div>
        )}

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 bg-white rounded-md shadow-lg animate-fadeDown">
            <nav className="flex flex-col py-2">
              <Link to="/" className="px-4 py-2 text-slate-800 hover:bg-gray-100">
                Home
              </Link>
              <Link to="/products" className="px-4 py-2 text-slate-800 hover:bg-gray-100">
                Shop
              </Link>
              <Link to="/about" className="px-4 py-2 text-slate-800 hover:bg-gray-100">
                About
              </Link>
              <Link to="/contact" className="px-4 py-2 text-slate-800 hover:bg-gray-100">
                Contact
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;